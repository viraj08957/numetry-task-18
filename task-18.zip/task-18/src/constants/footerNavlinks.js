export const footerNavlinks = [
	'FAQs',
	'privacy policy',
	'install guide',
	'contact us',
	'press-kit',
];
